import React from "react";
import styles from '../styles/nav.module.css';


export default function Nav(){
    return(
        <div className={styles.navcontainer}>
            <div className={styles.logo}>
                <p>sine<span className={styles.span}>MKT</span></p>
            </div>
            <div className={styles.list}>
                <ul>
                    <li>Home</li>
                    <li className={styles.new}>New Arrival</li>
                    <li>Features</li>
                    <li>Blog</li>
                    <li>Contact</li>
                </ul>
            

            </div>
            
           

        </div>
    
           
    )
}