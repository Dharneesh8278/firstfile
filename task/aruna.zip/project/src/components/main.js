import React from "react";
import styles from '../styles/main.module.css';

export default function Main(){
    return(
        <div className={styles.maincontainer}>
            <div className={styles.grid1}>
              
               <div className={styles.chair}>
                   <img src="https://m.media-amazon.com/images/I/411nPKJmp-L._AC_UL320_.jpg"></img>
               <h4>wooden chair</h4>
                <button className={styles.btn1}>SALE</button>
               
               </div>
               <div className={styles.chair}>
                   <img src="https://m.media-amazon.com/images/I/411nPKJmp-L._AC_UL320_.jpg"></img>
               <h4>single Arm chair</h4>
               <button className={styles.btn}>SALE</button>
               </div>
               <div className={styles.chair}>
                   <img src="https://m.media-amazon.com/images/I/411nPKJmp-L._AC_UL320_.jpg"></img>
               <h4>wooden arm chair</h4>
              
               </div>
               <div className={styles.chair}>
                   <img src="https://m.media-amazon.com/images/I/411nPKJmp-L._AC_UL320_.jpg"></img>
               <h4>stylish wooden chair</h4>
               <button className={styles.btn1}>SALE</button>
               </div>
               
            </div>
            <div className={styles.grid2}>
            <div className={styles.chair}>
                   <img src="https://m.media-amazon.com/images/I/411nPKJmp-L._AC_UL320_.jpg"></img>
              
               </div>
               <div className={styles.chair}>
                   <img src="https://m.media-amazon.com/images/I/411nPKJmp-L._AC_UL320_.jpg"></img>
                   <button className={styles.btn}>SALE</button>
              
               </div>
               <div className={styles.chair}>
                   <img src="https://m.media-amazon.com/images/I/411nPKJmp-L._AC_UL320_.jpg"></img>
                   <button className={styles.btn1}>SALE</button>
         
               </div>
               <div className={styles.chair}>
                   <img src="https://m.media-amazon.com/images/I/411nPKJmp-L._AC_UL320_.jpg"></img>
             
               </div>
           
            </div>

        </div>
       
    
           
    )
}